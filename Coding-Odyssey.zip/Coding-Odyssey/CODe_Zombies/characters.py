characters = [
    {
        "name": "Dempsey",
        "hp": 150,
        "favored_weapon": "AR",
        "has_juggernog": False,
        "has_double_tap": False,
        "has_deadshot_daiquiri": False
    },
    {     
        "name": "Nikolai",
        "hp": 150,
        "favored_weapon": "Shotgun",
        "has_juggernog": False,
        "has_double_tap": False,
        "has_deadshot_daiquiri": False
    },
    {
        "name": "Dr. Richtofen",
        "hp": 150,
        "favored_weapon": "SMG",
        "has_juggernog": False,
        "has_double_tap": False,
        "has_deadshot_daiquiri": False
    },
    {
        "name": "Takeo",
        "hp": 150,
        "favored_weapon": "Pistol",
        "has_juggernog": False,
        "has_double_tap": False,
        "has_deadshot_daiquiri": False
    }
]